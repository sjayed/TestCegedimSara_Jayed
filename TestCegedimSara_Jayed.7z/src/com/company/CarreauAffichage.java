package com.company;

import java.util.List;

public interface CarreauAffichage {


    void printResult(List<Integer> bools);
}
