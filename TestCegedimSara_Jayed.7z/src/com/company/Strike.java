package com.company;

import java.util.List;

public class Strike implements  Caclculator{


    @Override
    public int runCalculation(Integer boule, List<Integer> boules) {
        int result = 0;
        result = 10 + boule;
        int extraBoule = IOUtils.readCommandLine();
        boules.add(extraBoule);
        return result += extraBoule;
    }
}
