package com.company;

import java.util.Scanner;

public class IOUtils {

    private static Scanner scanner = new Scanner(System.in);


    public static  int readCommandLine(){

        System.out.print("Enter your result for this bool: ");

        return scanner.nextInt();

    }
}
