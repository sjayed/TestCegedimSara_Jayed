package com.company;

import java.util.List;

public class StrikeAffichage implements CarreauAffichage{


    @Override
    public void printResult(List<Integer> bools) {
        System.out.println("X");
        System.out.println(bools.stream().reduce((integer, integer2) -> integer + integer2));
    }
}
