package com.company;

import java.util.List;

public interface Caclculator {

    int runCalculation(Integer boule, List<Integer> booles);
}
