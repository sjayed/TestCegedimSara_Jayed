package com.company;

public class RoundResult {

    private CarreauAffichage carreauAffichage;

    public void printResult(){
        carreauAffichage = new StrikeAffichage();
    }
}
