package com.company;

import java.util.ArrayList;
import java.util.List;

public class Carreau {

    private int results;
    private ArrayList<Integer> boules;
    private Caclculator caclculator;
    private int id;

    public  Carreau(){

         boules = new ArrayList<>();
    }

    public void addBoule(List<Integer> boules){

        if(boules.get(0) == 10){
           caclculator = new Strike();
           caclculator.runCalculation(boules.get(1), this.boules);
        }else if(boules.get(0)<10){

        }

    }
}
